# R223M-P5 Golden Standard Lock Package

```text
stage_id=1013R_R223M_P5_GOLDEN_STANDARD_LOCK_PACKAGE
standard_id=GOLDEN_CLASSROOM_EVENT_EXPANSION_STANDARD_V0.1_LOCK_CANDIDATE
status=LOCK_CANDIDATE_REVIEW_PACKAGE
ZIP_SHA256=87E71E20C7A22A508714882352F90D6D3825B2E1781F7C3CF2A77A818E6C7111
formal_ui=blocked
R97B / UI / runtime / prompt / model / db = untouched
```

## Open First

- `R223M_P5_golden_standard_lock_report.md`
- `R223M_P5_teacher_default_reading_sample_v0_1.html`
- `R223M_P5_control_point_rubric_lock.md`
- `R223M_P5_cross_sample_validation_handoff.md`

## Purpose

This package locks the accepted P4-P1 teacher default reading layer and classroom-event expansion standard as v0.1 lock candidate. It does not alter classroom content, R97B, UI, runtime, provider/model, prompt, or database.
